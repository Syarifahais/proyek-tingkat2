package com.example.samplenotepad.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.samplenotepad.R;
import com.example.samplenotepad.model.notes;
import com.example.samplenotepad.utils.NoteUtils;

import java.sql.Array;
import java.util.ArrayList;

public class NotesAdapter extends RecyclerView.Adapter<NotesAdapter.NoteHolder>{

    private ArrayList<notes> note;
    private Context context;

    public NotesAdapter(ArrayList<notes> note, Context context) {
        this.note = note;
        this.context = context;
    }

    @Override
    public NoteHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View v = LayoutInflater.from(context).inflate(R.layout.activity_note,parent, false);
        return new NoteHolder(v);
    }

    @Override
    public void onBindViewHolder( NoteHolder noteHolder, int position) {
        notes note = getNote(position);
        if (note != null){
            noteHolder.noteText.setText(note.getNoteText());
            noteHolder.noteDate.setText(NoteUtils.dateFromLong(note.getNoteDate()));
        }
    }

    @Override
    public int getItemCount() {
        return note.size();
    }

    private notes getNote (int position){
        return note.get(position);
    }

    class NoteHolder extends RecyclerView.ViewHolder{
        TextView noteText, noteDate;

        public NoteHolder(@NonNull View itemView) {
            super(itemView);
            noteDate=itemView.findViewById(R.id.note_date);
            noteText=itemView.findViewById(R.id.note_text);
        }
    }
}
